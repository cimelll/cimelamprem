CIMELAM PREM — Vercel backend starter

Files:
- index.html
- api/premium-proxy.js

Install:
1. Extract this ZIP.
2. Upload index.html to the root of your GitHub repository.
3. Upload the entire api folder so the path is api/premium-proxy.js.
4. Commit changes and let Vercel redeploy the repository.
5. Test: https://YOUR-DOMAIN.vercel.app/api/premium-proxy?ping=1

Expected ping result:
{"online":true,"service":"CIMELAM PREM backend","activationConfigured":false}

Important:
This endpoint is a backend starter only. It does not send or verify Alight Motion activation links.
To enable real activation, a legitimate official provider/API and its server-side credentials are required.
Never paste private magic links or account tokens into a demo site.
